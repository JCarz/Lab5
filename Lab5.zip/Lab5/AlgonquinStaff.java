/**
 * An Algonquin College staff with salary.
 */
public class AlgonquinStaff {
	public String name;
	public double salary;

	/**
	 * Construct an AlgonquinStaff object.
	 * 
	 * @param n the name of the Algonquin staff
	 * @param s the salary of the Algonquin staff This method class is called the
	 *          super class the mother of all the subclasses Therefore we can
	 *          inherit from this class all methods and variables
	 */
	public AlgonquinStaff(String n, double s) {
		name = n;
		salary = s;
	}

	/**
	 * Returns the string represention of the object.
	 * 
	 * @return a string representation of the object
	 */
	public String toString() {
		return "AlgonquinStaff[name=" + name + ",salary=" + salary + "]";
	}
}