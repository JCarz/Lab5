/**
 * This program tests the AlgonquinStaff class and the subclasses you will
 * create. Remember to provide the necessary Javadoc style comments for your
 * code documentations explaining what you did at different points in your code.
 */
public class AlgonquinStaffTest {

	public static void main(String[] args) {

		Professor profObject = new Professor("Joe Smith", 88999.0);
		Professor profObject1 = new Professor("Brian Allen", 87654.0);
		Professor profObject2 = new Professor("Jennifer Rodriguez", 86543.0);
		Professor profObject3 = new Professor("Scott Miller", 85432.0);
		Chair chairObject = new Chair("Jaylen", 90000.0);

		System.out.println(profObject + "\n");
		System.out.println(profObject1 + "\n");
		System.out.println(profObject2 + "\n");
		System.out.println(profObject3 + "\n");
		System.out.println(chairObject + "\n");

	}
}
