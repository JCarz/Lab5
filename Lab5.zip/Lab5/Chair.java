public class Chair extends Professor {
	/**
	 * This class specifically read in plain English public class Chair inherits all
	 * methods and instance variables to the professor class
	 * 
	 * @param n the name of the Algonquin staff name
	 * @param s the salary of the Algonquin staff's salary
	 */
	// String faculty="Head of Department";
	public Chair(String n, double s) {
		super(n, s);
	}/*
		 * this inherits from the Algonquin Staff class's constructor using using the
		 * keyword "super" inside the constructor there is two parameters String and
		 * Double
		 * 
		 * @param n the name of the Algonquin staff name
		 * 
		 * @param s the salary of the Algonquin staff's salary
		 */

	public String toString() {
		return "AlgonquinStaff[name=" + name + ",salary=" + salary + ",faculty=" + faculty + "]";
	}// This toString is very simple it simply prints Name,Salary and faculty nothing
		// special.

}
